#!/usr/bin/env python3
"""
Script de prueba para generar un CSV simple con datos simulados.
Este script será ejecutado por GitHub Actions para probar la automatización.
"""

import csv
import datetime
import random

def generate_test_csv():
    """Genera un CSV de prueba con datos simulados."""
    
    # Datos de prueba
    countries = ['Chile', 'Argentina', 'Brasil', 'Colombia', 'Perú', 'México']
    
    # Generar datos simulados
    data = []
    for country in countries:
        row = {
            'Country': country,
            'Jiang_Stability': round(random.uniform(0, 1), 3),
            'Turchin_Instability': round(random.uniform(0, 1), 3),
            'RISK_Indicator': round(random.uniform(0, 1), 3),
            'Gini_Index': round(random.uniform(25, 65), 1),
            'Youth_Unemployment': round(random.uniform(5, 35), 1),
            'Last_Updated': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        data.append(row)
    
    # Escribir CSV
    filename = 'test_data.csv'
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Country', 'Jiang_Stability', 'Turchin_Instability', 
                     'RISK_Indicator', 'Gini_Index', 'Youth_Unemployment', 'Last_Updated']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for row in data:
            writer.writerow(row)
    
    print(f"✅ CSV generado exitosamente: {filename}")
    print(f"📊 Datos para {len(data)} países")
    print(f"🕒 Última actualización: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    generate_test_csv()

