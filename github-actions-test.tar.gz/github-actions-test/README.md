# GitHub Actions CSV Generator - Prueba

Este repositorio es una prueba para automatizar la generación de archivos CSV usando GitHub Actions.

## 🎯 Objetivo

Probar la automatización de:
1. Ejecución de un script Python
2. Generación de un archivo CSV
3. Commit automático del archivo actualizado al repositorio

## 📁 Archivos

- `generate_test_csv.py`: Script que genera datos de prueba en formato CSV
- `test_data.csv`: Archivo CSV generado automáticamente (se actualiza cada día)
- `.github/workflows/generate-csv.yml`: Configuración de GitHub Actions

## ⚙️ Funcionamiento

El workflow se ejecuta:
- **Automáticamente**: Cada día a las 6:00 AM UTC (3:00 AM Chile)
- **Manualmente**: Desde la pestaña "Actions" en GitHub
- **Al hacer push**: Cuando se actualiza el código en la rama main

## 📊 Acceso al CSV

El archivo CSV estará disponible en:
- **Repositorio**: `https://github.com/cnav-cl/NOMBRE_REPO/blob/main/test_data.csv`
- **Raw (para consumo directo)**: `https://raw.githubusercontent.com/cnav-cl/NOMBRE_REPO/main/test_data.csv`

## 🚀 Próximos pasos

Una vez que esta prueba funcione correctamente, migraremos al script real de análisis sociopolítico con datos del Banco Mundial, UCDP y GDELT.

